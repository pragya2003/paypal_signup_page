# Paypal_Signup_Page_17-04-23
Create a responsive PayPal signup page website using HTML and CSS in this step-by-step tutorial. 
